
var canvas =  document.getElementById('canvas'),
	context = canvas.getContext("2d");
	context.imageSmoothingEnabled = false;


const VITESSE_MAX = 5;



var x = canvas.width / 2;
var y = canvas.height / 2;

var vitesseX = 0;
var vitesseY = 2;

var stay = true;


function maxSpeedX(vitesseX) {
	if(vitesseX > VITESSE_MAX) {
		vitesseX = VITESSE_MAX;
	}
	if(vitesseX < -VITESSE_MAX) {
		vitesseX = -VITESSE_MAX;
	}
	return vitesseX;
} 


var step =0;
var timeline =0;
var r = 40;
var sprites = new Image();
sprites.src = "Bomber.png";

sprites.onload = animate;


window.addEventListener('keydown', function(e) {
	var r = e;
	switch (e.key) {
		case "d":
			vitesseX++;
			vitesseX = maxSpeedX(vitesseX);
			break;
		case "q":
			vitesseX--;
			break;
		case " ":
			stay = false;
			break;
	}
})




function animate(){
	draw();
	requestAnimationFrame(animate);

	

  	update();
}

function draw(){
	context.clearRect(0, 0, canvas.width, canvas.height);
	if(stay) {

		context.drawImage(sprites, 64, 0, 64, 64, x, y, 32, 32 );
	} else {

		drawBomber(x, y, step);	
	}
	x += vitesseX;
}

function drawBomber(x, y, step){
	var s = r/8;
	context.drawImage(sprites, 64*step, 0, 64, 64, x, y, 32, 32 );
}



function update() {
 timeline++;
 if (timeline==2){
 	timeline=0;
 	    step++;
 }
    
  if (step >= 8) {
  	step = 0;
  	stay = true;
  } 
}
	